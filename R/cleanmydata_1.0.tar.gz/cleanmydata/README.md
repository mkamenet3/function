This is a second attempt at my package and GitHub
